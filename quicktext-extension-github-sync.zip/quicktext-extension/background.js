// Seeds a couple of example snippets the first time the extension is
// installed, so the database (and the expansion behavior) isn't empty on
// first use. Each snippet stores both a rich `html` version (used when
// expanding into a rich/contenteditable field, e.g. Gmail) and a plain
// `text` fallback (used for plain <input>/<textarea> fields).
const DEFAULT_SNIPPETS = {
  sig: {
    html: "Best regards,<br><b>Your Name</b>",
    text: "Best regards,\nYour Name"
  },
  addr: {
    html: "123 Main Street, Suite 400, Springfield",
    text: "123 Main Street, Suite 400, Springfield"
  },
  em: {
    html: "you@example.com",
    text: "you@example.com"
  },
  ty: {
    html: "Thanks so much \u2014 I <i>really</i> appreciate it!",
    text: "Thanks so much \u2014 I really appreciate it!"
  }
};

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason !== "install") return;
  const existing = await chrome.storage.local.get("snippets");
  if (!existing.snippets) {
    await chrome.storage.local.set({ snippets: DEFAULT_SNIPPETS });
  }
});

// --- GitHub auto-sync -----------------------------------------------------
// Optional: when the user turns on "Keep in sync automatically" in the
// options page, this pushes local edits up to GitHub as they happen, and
// periodically pulls down anything changed elsewhere (another machine,
// someone editing the file directly on GitHub, etc.).

importScripts("lib/github-sync.js");

const GH_PULL_ALARM = "qt-github-pull";
const GH_PULL_PERIOD_MINUTES = 5;

// Set after autoPull() applies a remote change, so the storage.onChanged
// handler below doesn't immediately push that same change right back.
let suppressNextAutoPush = false;

async function armOrDisarmPullAlarm(config) {
  if (config.autoSync && QTGithub.isConfigured(config)) {
    chrome.alarms.create(GH_PULL_ALARM, { periodInMinutes: GH_PULL_PERIOD_MINUTES });
  } else {
    chrome.alarms.clear(GH_PULL_ALARM);
  }
}

async function autoPush() {
  if (suppressNextAutoPush) {
    suppressNextAutoPush = false;
    return;
  }
  const config = await QTGithub.getConfig();
  if (!config.autoSync || !QTGithub.isConfigured(config)) return;

  const { snippets } = await chrome.storage.local.get("snippets");
  try {
    const result = await QTGithub.push(config, snippets || {}, config.lastSyncedSha);
    await QTGithub.setConfig({ lastSyncedSha: result.sha, lastSyncedAt: Date.now(), lastError: null });
  } catch (err) {
    // Most likely a stale sha because the remote file moved on since we last
    // saw it (edited elsewhere). Re-fetch the current sha and retry once.
    try {
      const remote = await QTGithub.pull(config);
      const result = await QTGithub.push(config, snippets || {}, remote.sha);
      await QTGithub.setConfig({ lastSyncedSha: result.sha, lastSyncedAt: Date.now(), lastError: null });
    } catch (err2) {
      await QTGithub.setConfig({ lastError: String((err2 && err2.message) || err2) });
    }
  }
}

async function autoPull() {
  const config = await QTGithub.getConfig();
  if (!config.autoSync || !QTGithub.isConfigured(config)) return;
  try {
    const remote = await QTGithub.pull(config);
    if (!remote.sha || remote.sha === config.lastSyncedSha) return; // nothing new
    const local = await chrome.storage.local.get("snippets");
    // Remote entries win on key collisions; local-only keys are kept.
    const merged = { ...(local.snippets || {}), ...(remote.snippets || {}) };
    suppressNextAutoPush = true;
    await chrome.storage.local.set({ snippets: merged });
    await QTGithub.setConfig({ lastSyncedSha: remote.sha, lastSyncedAt: Date.now(), lastError: null });
  } catch (err) {
    await QTGithub.setConfig({ lastError: String((err && err.message) || err) });
  }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.snippets) autoPush();
  if (changes.githubSync) armOrDisarmPullAlarm(changes.githubSync.newValue || {});
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === GH_PULL_ALARM) autoPull();
});

// Re-arm the pull alarm on browser startup and on install/update, in case
// auto-sync was already turned on (alarms don't survive a browser restart).
chrome.runtime.onStartup.addListener(async () => {
  armOrDisarmPullAlarm(await QTGithub.getConfig());
});
chrome.runtime.onInstalled.addListener(async () => {
  armOrDisarmPullAlarm(await QTGithub.getConfig());
});
