let snippets = {};

const listEl = document.getElementById("list");
const emptyEl = document.getElementById("empty");
const searchEl = document.getElementById("search");
const kwInput = document.getElementById("kwInput");
const phraseInput = document.getElementById("phraseInput");
const errEl = document.getElementById("err");

function normalizeEntry(entry) {
  if (typeof entry === "string") return { html: null, text: entry };
  return { html: entry.html || null, text: entry.text || "" };
}

function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function textToHtml(text) {
  return escapeHtml(text).split("\n").join("<br>");
}

function load() {
  chrome.storage.local.get("snippets", (data) => {
    snippets = data.snippets || {};
    render();
  });
}

function render() {
  const query = searchEl.value.trim().toLowerCase();
  const keys = Object.keys(snippets)
    .filter((k) => {
      if (!query) return true;
      const entry = normalizeEntry(snippets[k]);
      return (
        k.toLowerCase().includes(query) ||
        entry.text.toLowerCase().includes(query)
      );
    })
    .sort((a, b) => a.localeCompare(b));

  listEl.innerHTML = "";
  emptyEl.hidden = Object.keys(snippets).length !== 0;

  for (const key of keys) {
    const entry = normalizeEntry(snippets[key]);
    const li = document.createElement("li");
    li.className = "popup__row";
    const kwSpan = document.createElement("span");
    kwSpan.className = "popup__kw";
    kwSpan.textContent = "." + key;
    const phraseSpan = document.createElement("span");
    phraseSpan.className = "popup__phrase";
    phraseSpan.textContent = entry.text;
    li.appendChild(kwSpan);
    li.appendChild(phraseSpan);
    listEl.appendChild(li);
  }
}

document.getElementById("manageBtn").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

document.getElementById("useSelectionBtn").addEventListener("click", async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => window.getSelection().toString(),
    });
    if (result) {
      phraseInput.value = result;
      phraseInput.focus();
    } else {
      errEl.textContent = "Nothing selected on the page.";
      setTimeout(() => (errEl.textContent = ""), 2000);
    }
  } catch (e) {
    errEl.textContent = "Can't read this page.";
    setTimeout(() => (errEl.textContent = ""), 2000);
  }
});

document.getElementById("saveBtn").addEventListener("click", () => {
  const key = kwInput.value.trim().replace(/^\.+/, "");
  const text = phraseInput.value;

  if (!key) {
    errEl.textContent = "Give the keyword a name.";
    return;
  }
  if (!/^[A-Za-z0-9_-]{1,40}$/.test(key)) {
    errEl.textContent = "Letters, numbers, _ or - only.";
    return;
  }
  if (!text) {
    errEl.textContent = "Add the text to expand to.";
    return;
  }
  if (snippets[key] !== undefined) {
    errEl.textContent = `.${key} already exists.`;
    return;
  }

  // Stored as { html, text } for consistency with the manager's rich-text
  // editor — html is just the plain text with line breaks for now; anyone
  // wanting bold/italic/lists can open "Manage all" and add formatting.
  const next = { ...snippets, [key]: { html: textToHtml(text), text } };
  chrome.storage.local.set({ snippets: next }, () => {
    snippets = next;
    kwInput.value = "";
    phraseInput.value = "";
    errEl.textContent = "";
    render();
  });
});

searchEl.addEventListener("input", render);

load();
