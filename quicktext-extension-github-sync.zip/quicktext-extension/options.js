let snippets = {};
let editingKey = null; // null = creating new

const listEl = document.getElementById("list");
const emptyEl = document.getElementById("empty");
const countEl = document.getElementById("count");
const searchEl = document.getElementById("search");
const editorEl = document.getElementById("editor");
const kwInput = document.getElementById("kwInput");
const phraseInput = document.getElementById("phraseInput"); // contenteditable rich text box
const editorError = document.getElementById("editorError");

// --- snippet normalization (mirrors content.js) ---------------------------

function normalizeEntry(entry) {
  if (typeof entry === "string") return { html: null, text: entry };
  return { html: entry.html || null, text: entry.text || "" };
}

function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function textToHtml(text) {
  return escapeHtml(text).split("\n").join("<br>");
}

// --- HTML sanitizing --------------------------------------------------
// Strips anything beyond simple formatting before a snippet is saved, so a
// snippet (including one merged in from an imported JSON file) can never
// carry scripts or event-handler attributes that would run later when the
// snippet is inserted into some other page.

const ALLOWED_TAGS = new Set([
  "B", "STRONG", "I", "EM", "U", "BR", "UL", "OL", "LI", "A", "SPAN", "DIV", "P"
]);

function sanitizeHtml(html) {
  const template = document.createElement("template");
  template.innerHTML = html;

  function clean(parent) {
    Array.from(parent.childNodes).forEach((child) => {
      if (child.nodeType === Node.ELEMENT_NODE) {
        if (!ALLOWED_TAGS.has(child.tagName)) {
          while (child.firstChild) parent.insertBefore(child.firstChild, child);
          parent.removeChild(child);
          return;
        }
        Array.from(child.attributes).forEach((attr) => {
          if (child.tagName === "A" && attr.name === "href") {
            if (/^\s*javascript:/i.test(attr.value)) child.removeAttribute("href");
          } else {
            child.removeAttribute(attr.name);
          }
        });
        clean(child);
      } else if (child.nodeType !== Node.TEXT_NODE) {
        parent.removeChild(child);
      }
    });
  }
  clean(template.content);
  return template.innerHTML;
}

// --- storage --------------------------------------------------------------

function load() {
  chrome.storage.local.get("snippets", (data) => {
    snippets = data.snippets || {};
    render();
  });
}

function save(newSnippets) {
  snippets = newSnippets;
  chrome.storage.local.set({ snippets });
}

// --- list rendering ---------------------------------------------------

function render() {
  const query = searchEl.value.trim().toLowerCase();
  const keys = Object.keys(snippets).sort((a, b) => a.localeCompare(b));
  const filtered = keys.filter((k) => {
    if (!query) return true;
    const entry = normalizeEntry(snippets[k]);
    return (
      k.toLowerCase().includes(query) ||
      entry.text.toLowerCase().includes(query)
    );
  });

  countEl.textContent = `${keys.length} snippet${keys.length === 1 ? "" : "s"}`;
  listEl.innerHTML = "";

  if (filtered.length === 0) {
    emptyEl.hidden = keys.length !== 0;
    listEl.hidden = keys.length === 0;
    if (keys.length !== 0) {
      const li = document.createElement("li");
      li.className = "row";
      li.innerHTML = `<span style="color:var(--ink-soft)">No matches for "${escapeHtml(
        query
      )}".</span>`;
      listEl.appendChild(li);
    }
    return;
  }

  emptyEl.hidden = true;
  listEl.hidden = false;

  for (const key of filtered) {
    const entry = normalizeEntry(snippets[key]);
    const li = document.createElement("li");
    li.className = "row";
    li.innerHTML = `
      <span class="row__kw">.${escapeHtml(key)}</span>
      <span class="row__phrase"></span>
      <span class="row__actions">
        <button class="icon-btn" data-action="edit" data-key="${escapeHtml(
          key
        )}">Edit</button>
        <button class="icon-btn icon-btn--danger" data-action="delete" data-key="${escapeHtml(
          key
        )}">Delete</button>
      </span>
    `;
    li.querySelector(".row__phrase").textContent = entry.text;
    listEl.appendChild(li);
  }
}

// --- editor -------------------------------------------------------------

function openEditor(key) {
  editingKey = key || null;
  if (key) {
    const entry = normalizeEntry(snippets[key]);
    kwInput.value = key;
    phraseInput.innerHTML = entry.html !== null ? entry.html : textToHtml(entry.text);
  } else {
    kwInput.value = "";
    phraseInput.innerHTML = "";
  }
  editorError.textContent = "";
  editorEl.hidden = false;
  kwInput.focus();
  updateToolbarState();
}

function closeEditor() {
  editorEl.hidden = true;
  editingKey = null;
}

document.getElementById("newBtn").addEventListener("click", () => openEditor(null));
document.getElementById("cancelBtn").addEventListener("click", closeEditor);

document.getElementById("saveBtn").addEventListener("click", () => {
  const key = kwInput.value.trim().replace(/^\.+/, "");

  if (!key) {
    editorError.textContent = "Give the keyword a name.";
    return;
  }
  if (!/^[A-Za-z0-9_-]{1,40}$/.test(key)) {
    editorError.textContent = "Use letters, numbers, _ or - only (no spaces).";
    return;
  }
  const text = phraseInput.innerText.replace(/\n+$/, "");
  if (!text.trim()) {
    editorError.textContent = "Add the text it should expand to.";
    return;
  }
  if (key !== editingKey && snippets[key] !== undefined) {
    editorError.textContent = `.${key} already exists.`;
    return;
  }

  const html = sanitizeHtml(phraseInput.innerHTML);
  const next = { ...snippets };
  if (editingKey && editingKey !== key) delete next[editingKey];
  next[key] = { html, text };
  save(next);
  closeEditor();
  render();
});

// --- formatting toolbar -------------------------------------------------

document.querySelectorAll(".rt-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    phraseInput.focus();
    document.execCommand(btn.dataset.cmd, false, null);
    updateToolbarState();
  });
});

function updateToolbarState() {
  document.querySelectorAll(".rt-btn[data-cmd]").forEach((btn) => {
    const cmd = btn.dataset.cmd;
    if (cmd === "removeFormat") return;
    try {
      btn.classList.toggle("is-active", document.queryCommandState(cmd));
    } catch (e) {
      // some commands (e.g. list state right after DOM changes) can throw; ignore
    }
  });
}

phraseInput.addEventListener("keyup", updateToolbarState);
phraseInput.addEventListener("mouseup", updateToolbarState);
document.addEventListener("selectionchange", () => {
  if (!editorEl.hidden && document.activeElement === phraseInput) {
    updateToolbarState();
  }
});

// --- list actions ---------------------------------------------------------

listEl.addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-action]");
  if (!btn) return;
  const key = btn.dataset.key;
  if (btn.dataset.action === "edit") {
    openEditor(key);
  } else if (btn.dataset.action === "delete") {
    if (confirm(`Delete .${key}? This can't be undone.`)) {
      const next = { ...snippets };
      delete next[key];
      save(next);
      render();
    }
  }
});

searchEl.addEventListener("input", render);

// --- import / export -------------------------------------------------------

document.getElementById("exportBtn").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(snippets, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "quicktext-snippets.json";
  a.click();
  URL.revokeObjectURL(url);
});

// Cleans a parsed snippets object (from an imported file or pulled from
// GitHub) the same way, then merges it into the current set. Incoming keys
// win on collisions; sanitizeHtml keeps anything imported from carrying
// scripts or event-handler attributes.
function mergeIncomingSnippets(parsed) {
  if (typeof parsed !== "object" || Array.isArray(parsed) || !parsed) {
    throw new Error("bad shape");
  }
  const cleaned = {};
  for (const [key, value] of Object.entries(parsed)) {
    const entry = normalizeEntry(value);
    cleaned[key] = {
      html: sanitizeHtml(entry.html !== null ? entry.html : textToHtml(entry.text)),
      text: entry.text,
    };
  }
  const merged = { ...snippets, ...cleaned };
  save(merged);
  render();
}

document.getElementById("importFile").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      mergeIncomingSnippets(JSON.parse(reader.result));
    } catch (err) {
      alert("That file doesn't look like a valid QuickText export.");
    }
  };
  reader.readAsText(file);
  e.target.value = "";
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.snippets) {
    snippets = changes.snippets.newValue || {};
    render();
  }
  if (area === "local" && changes.githubSync) {
    renderGithubStatus(changes.githubSync.newValue || {});
  }
});

// --- GitHub sync panel ------------------------------------------------

const githubBtn = document.getElementById("githubBtn");
const githubPanel = document.getElementById("githubPanel");
const ghRepoEl = document.getElementById("ghRepo");
const ghPathEl = document.getElementById("ghPath");
const ghBranchEl = document.getElementById("ghBranch");
const ghTokenEl = document.getElementById("ghToken");
const ghAutoSyncEl = document.getElementById("ghAutoSync");
const ghStatusEl = document.getElementById("ghStatus");
const ghSaveBtn = document.getElementById("ghSaveBtn");
const ghPullBtn = document.getElementById("ghPullBtn");
const ghPushBtn = document.getElementById("ghPushBtn");
const ghDisconnectBtn = document.getElementById("ghDisconnectBtn");

function parseRepoField(value) {
  const cleaned = value.trim().replace(/^https?:\/\/github\.com\//i, "").replace(/\/$/, "");
  const [owner = "", repo = ""] = cleaned.split("/");
  return { owner, repo: repo.replace(/\.git$/, "") };
}

function renderGithubStatus(config) {
  ghDisconnectBtn.hidden = !QTGithub.isConfigured(config);
  if (config.lastError) {
    ghStatusEl.textContent = `Error: ${config.lastError}`;
    ghStatusEl.style.color = "var(--danger)";
  } else if (config.lastSyncedAt) {
    ghStatusEl.style.color = "";
    ghStatusEl.textContent = `Last synced ${new Date(config.lastSyncedAt).toLocaleString()}`;
  } else if (QTGithub.isConfigured(config)) {
    ghStatusEl.style.color = "";
    ghStatusEl.textContent = "Connected, not yet synced.";
  } else {
    ghStatusEl.style.color = "";
    ghStatusEl.textContent = "Not connected.";
  }
}

async function loadGithubPanel() {
  const config = await QTGithub.getConfig();
  ghRepoEl.value = config.owner && config.repo ? `${config.owner}/${config.repo}` : "";
  ghPathEl.value = config.path || "quicktext-snippets.json";
  ghBranchEl.value = config.branch || "main";
  ghTokenEl.value = config.token || "";
  ghAutoSyncEl.checked = !!config.autoSync;
  renderGithubStatus(config);
}

githubBtn.addEventListener("click", () => {
  githubPanel.hidden = !githubPanel.hidden;
  if (!githubPanel.hidden) loadGithubPanel();
});

ghSaveBtn.addEventListener("click", async () => {
  const { owner, repo } = parseRepoField(ghRepoEl.value);
  const patch = {
    owner,
    repo,
    path: ghPathEl.value.trim() || "quicktext-snippets.json",
    branch: ghBranchEl.value.trim() || "main",
    token: ghTokenEl.value.trim(),
    autoSync: ghAutoSyncEl.checked,
  };
  if (!patch.owner || !patch.repo || !patch.token) {
    ghStatusEl.textContent = "Fill in the repository (owner/repo) and a personal access token first.";
    ghStatusEl.style.color = "var(--danger)";
    return;
  }
  ghSaveBtn.disabled = true;
  ghStatusEl.style.color = "";
  ghStatusEl.textContent = "Testing connection…";
  try {
    await QTGithub.setConfig(patch);
    const config = await QTGithub.getConfig();
    await QTGithub.testConnection(config);
    await QTGithub.setConfig({ lastError: null });
    ghStatusEl.textContent = "Connected. You can pull or push snippets now.";
  } catch (err) {
    await QTGithub.setConfig({ lastError: err.message });
    ghStatusEl.textContent = `Error: ${err.message}`;
    ghStatusEl.style.color = "var(--danger)";
  } finally {
    ghDisconnectBtn.hidden = !QTGithub.isConfigured(await QTGithub.getConfig());
    ghSaveBtn.disabled = false;
  }
});

ghPullBtn.addEventListener("click", async () => {
  const config = await QTGithub.getConfig();
  if (!QTGithub.isConfigured(config)) {
    ghStatusEl.textContent = "Save a connection first.";
    ghStatusEl.style.color = "var(--danger)";
    return;
  }
  ghPullBtn.disabled = true;
  ghStatusEl.style.color = "";
  ghStatusEl.textContent = "Pulling…";
  try {
    const remote = await QTGithub.pull(config);
    if (remote.snippets === null) {
      ghStatusEl.textContent = "No file there yet — use Push to GitHub to create it.";
      return;
    }
    mergeIncomingSnippets(remote.snippets);
    await QTGithub.setConfig({ lastSyncedSha: remote.sha, lastSyncedAt: Date.now(), lastError: null });
    renderGithubStatus(await QTGithub.getConfig());
  } catch (err) {
    await QTGithub.setConfig({ lastError: err.message });
    ghStatusEl.textContent = `Error: ${err.message}`;
    ghStatusEl.style.color = "var(--danger)";
  } finally {
    ghPullBtn.disabled = false;
  }
});

ghPushBtn.addEventListener("click", async () => {
  const config = await QTGithub.getConfig();
  if (!QTGithub.isConfigured(config)) {
    ghStatusEl.textContent = "Save a connection first.";
    ghStatusEl.style.color = "var(--danger)";
    return;
  }
  ghPushBtn.disabled = true;
  ghStatusEl.style.color = "";
  ghStatusEl.textContent = "Pushing…";
  try {
    let sha = config.lastSyncedSha;
    if (!sha) {
      // No known sha yet — check whether the file already exists so we
      // don't accidentally overwrite it without one.
      const remote = await QTGithub.pull(config);
      sha = remote.sha;
    }
    const result = await QTGithub.push(config, snippets, sha);
    await QTGithub.setConfig({ lastSyncedSha: result.sha, lastSyncedAt: Date.now(), lastError: null });
    renderGithubStatus(await QTGithub.getConfig());
  } catch (err) {
    await QTGithub.setConfig({ lastError: err.message });
    ghStatusEl.textContent = `Error: ${err.message}`;
    ghStatusEl.style.color = "var(--danger)";
  } finally {
    ghPushBtn.disabled = false;
  }
});

ghAutoSyncEl.addEventListener("change", async () => {
  await QTGithub.setConfig({ autoSync: ghAutoSyncEl.checked });
});

ghDisconnectBtn.addEventListener("click", async () => {
  if (
    !confirm(
      "Disconnect from GitHub? This clears the saved token and repository settings on this device. Your snippets themselves aren't affected."
    )
  ) {
    return;
  }
  await QTGithub.setConfig({
    token: "",
    owner: "",
    repo: "",
    autoSync: false,
    lastSyncedSha: null,
    lastSyncedAt: null,
    lastError: null,
  });
  loadGithubPanel();
});

load();
