// QuickText content script
// Watches typing in text inputs, textareas, and contenteditable elements.
// When the user types ".keyword" followed by a delimiter (space/tab/enter),
// or types a keyword that exactly matches a shortcut with no longer shortcut
// sharing its prefix, the shortcut is replaced with the saved snippet.
//
// Snippets are stored as { html, text } — html carries formatting (bold,
// italic, lists, line breaks) for rich/contenteditable fields, text is a
// plain-text fallback for plain <input>/<textarea> fields. Older snippets
// saved before rich text was added may still be plain strings; those are
// treated as text-only with no formatting.
//
// Insertion is done with a single browser editing command (execCommand)
// rather than by rewriting DOM/value directly or chaining several commands.
// Chaining several commands together to simulate pressing Enter (an earlier
// version of this script did that) gave rich editors like Gmail — which
// keep their own internal copy of the document and resync it against real
// edits — more chances to duplicate content. One call is one atomic edit.

(() => {
  let snippets = {};
  let expanding = false; // re-entrancy guard around our own execCommand calls

  function loadSnippets() {
    chrome.storage.local.get("snippets", (data) => {
      snippets = data.snippets || {};
    });
  }
  loadSnippets();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.snippets) {
      snippets = changes.snippets.newValue || {};
    }
  });

  const KEYWORD_RE = /(^|[\s])\.([A-Za-z0-9_-]{1,40})$/;
  const DELIM_KEYWORD_RE = /(^|[\s])\.([A-Za-z0-9_-]{1,40})([ \t\n])$/;

  function hasLongerSibling(keyword) {
    for (const key of Object.keys(snippets)) {
      if (key !== keyword && key.startsWith(keyword)) return true;
    }
    return false;
  }

  // Normalizes a stored snippet (either the new { html, text } shape or a
  // legacy plain string) into { html, text }.
  function normalizeEntry(entry) {
    if (typeof entry === "string") {
      return { html: null, text: entry };
    }
    return { html: entry.html || null, text: entry.text || "" };
  }

  // Given the text immediately before the caret, find a ".keyword" match
  // (delimiter-triggered takes priority over instant-triggered) and return
  // { entry, matchStart, matchEnd } offsets into that text, or null if
  // nothing should expand.
  function findMatch(before) {
    let m = before.match(DELIM_KEYWORD_RE);
    let delimLen = 1;
    if (!m) {
      m = before.match(KEYWORD_RE);
      delimLen = 0;
      if (!m) return null;
      const kw = m[2];
      if (!(kw in snippets) || hasLongerSibling(kw)) return null;
    }
    const keyword = m[2];
    if (!(keyword in snippets)) return null;
    const entry = normalizeEntry(snippets[keyword]);

    const matchStart = before.length - m[0].length + m[1].length; // start of "."
    const matchEnd = before.length - delimLen; // end of keyword, excludes delimiter
    return { entry, matchStart, matchEnd };
  }

  function escapeHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  // Fallback for turning plain text into an HTML fragment with real <br>
  // line breaks, used only when a snippet has no stored `html` version.
  function textToHtml(text) {
    return escapeHtml(text).split("\n").join("<br>");
  }

  // Inserts `entry` ({ html, text }) at the current (collapsed-after-
  // selecting) selection. This is deliberately ONE execCommand call.
  //
  //  - 'input'          : single-line field, can't show line breaks or
  //                        formatting at all — always uses plain text
  //  - 'textarea'        : plain-text control — "\n" already renders as a
  //                        real line break natively, but it can't show
  //                        bold/italic/etc., so it also uses plain text
  //  - 'contenteditable' : rich field (Gmail, etc.) — uses the snippet's
  //                        HTML so formatting and line breaks survive,
  //                        falling back to escaped plain text with <br>s
  //                        if the snippet predates rich-text support
  function insertPhrase(entry, mode) {
    if (mode === "input") {
      document.execCommand("insertText", false, entry.text.replace(/\r?\n+/g, " "));
    } else if (mode === "textarea") {
      document.execCommand("insertText", false, entry.text);
    } else {
      const html = entry.html !== null ? entry.html : textToHtml(entry.text);
      document.execCommand("insertHTML", false, html);
    }
  }

  function expandInInputLike(el) {
    const cursor = el.selectionStart;
    if (cursor == null) return false;
    const match = findMatch(el.value.slice(0, cursor));
    if (!match) return false;

    const { entry, matchStart, matchEnd } = match;
    const mode = el.tagName === "TEXTAREA" ? "textarea" : "input";

    expanding = true;
    el.focus();
    el.setSelectionRange(matchStart, matchEnd);
    insertPhrase(entry, mode);
    expanding = false;
    return true;
  }

  function expandInContentEditable() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0 || !sel.isCollapsed) return false;
    const range = sel.getRangeAt(0);
    const node = range.startContainer;
    if (node.nodeType !== Node.TEXT_NODE) return false;

    const offset = range.startOffset;
    const match = findMatch(node.textContent.slice(0, offset));
    if (!match) return false;

    const { entry, matchStart, matchEnd } = match;

    const selRange = document.createRange();
    selRange.setStart(node, matchStart);
    selRange.setEnd(node, matchEnd);
    sel.removeAllRanges();
    sel.addRange(selRange);

    expanding = true;
    insertPhrase(entry, "contenteditable");
    expanding = false;
    return true;
  }

  function isTextField(el) {
    if (!el) return false;
    const tag = el.tagName;
    if (tag === "TEXTAREA") return true;
    if (tag === "INPUT") {
      const type = (el.type || "text").toLowerCase();
      return ["text", "search", "url", "email", "tel"].includes(type);
    }
    return false;
  }

  document.addEventListener(
    "input",
    (e) => {
      if (expanding) return;
      if (!Object.keys(snippets).length) return;
      const el = e.target;
      if (isTextField(el)) {
        expandInInputLike(el);
      } else if (el && el.isContentEditable) {
        expandInContentEditable();
      }
    },
    true
  );
})();
