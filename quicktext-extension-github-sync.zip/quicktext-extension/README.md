# QuickText — Snippet Expander

A lightweight Chrome extension (Blaze/Text Blaze–style) that expands a
`.keyword` you type into a saved phrase or paragraph, in almost any text
field on the web.

## Install (unpacked / developer mode)

1. Unzip this folder somewhere permanent (don't delete it after installing —
   Chrome loads the extension from these files).
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select the unzipped `quicktext-extension`
   folder.
5. Pin the extension (puzzle-piece icon → pin) so its icon stays visible.

## Use it

- Type `.` followed by a keyword (e.g. `.sig`) into any input box, textarea,
  or editable field (Gmail, Google Docs comments, most web forms), then a
  space/tab/enter — it expands into the saved text.
- If a keyword isn't a prefix of any other keyword, it expands the instant
  you finish typing it — no space needed.
- Snippets can be plain text or formatted (bold, italic, underline, lists) —
  set that up in the manager's "Expands to" editor. Formatting and line
  breaks are preserved when expanding into a rich field like Gmail; a plain
  `<textarea>`/`<input>` shows the plain-text version instead, since those
  fields can't display formatting.
- Three example snippets (`.sig`, `.addr`, `.em`, `.ty`) are pre-loaded so
  you can try it immediately.

## Manage your snippet database

- Click the extension icon for a quick popup: search, preview, and add a
  new plain-text snippet (including turning selected page text into one).
- Click **Manage all** in the popup, or right-click the icon →
  **Options**, to open the full manager. There you can add, edit, delete
  and search snippets, format them with the toolbar above the "Expands to"
  box (bold, italic, underline, bulleted/numbered lists, clear formatting),
  and **Export**/**Import** your whole snippet set as JSON (handy for
  backup or moving to another computer — imported HTML is sanitized down to
  that same basic formatting set before it's saved).

## GitHub Sync

Instead of (or in addition to) manual Export/Import, you can link a GitHub
repo and keep your snippet file there:

1. Open the manager (Options) and click **GitHub Sync**.
2. Enter the repo as `owner/repo`, the path to the JSON file inside it
   (defaults to `quicktext-snippets.json` — it'll be created if it doesn't
   exist), and the branch (defaults to `main`).
3. Create a token at
   [github.com/settings/personal-access-tokens/new](https://github.com/settings/personal-access-tokens/new) —
   a **fine-grained** token scoped to just that one repo, with **Contents:
   Read and write** permission, is enough. Paste it in and click
   **Save & test connection**.
4. Use **Pull from GitHub** / **Push to GitHub** to sync on demand, or check
   **Keep in sync automatically** to push local edits right away and check
   for remote changes every few minutes in the background.

Notes:
- The token is stored only on this device (`chrome.storage.local`) and is
  never included in a regular Export.
- Pulling merges into your existing snippets; incoming keys win on a name
  collision. Pushing overwrites the file in GitHub with your current set.
- Auto-sync resolves most conflicts by refetching the file's latest version
  and retrying, but if you edit the same keyword in two places at once,
  whichever push lands second wins.

## Notes / limitations

- Works in standard `<input>`/`<textarea>` fields and `contenteditable`
  areas. It won't work inside canvas-based editors (e.g. some parts of
  Google Docs' main body) since those don't expose editable text to
  extensions.
- Data is stored locally via `chrome.storage.local` — it isn't synced or
  sent anywhere, unless you set up GitHub Sync above (in which case your
  snippets and, for API calls, your token are sent to `api.github.com`).
